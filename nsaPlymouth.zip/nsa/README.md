##nsa-plymouth##

NSA-Style plymouth bootsplash for Ubuntu.

Original Project By: SKD1993
Project Updated 09/2020 By: NiCore

Current Version: 1.3b
Test on Ubuntu 18.04->20.04.1

##Installation Instructions##    

The theme can be easily installed by running install.sh from your download directory

Alternatively it can be done manually by copying the NSA folder to the plymouth location of:

# /usr/share/plymouth/themes/

Then add your new theme to Plymouth

Note: at the end of the command is a number that will show up when selecting a default splash so if the number listed at the end
      is the same as one you have already added, change it so it is unique and then issue the command.

# sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth /usr/share/plymouth/themes/nsa/nsa.plymouth 110

##Previewing the theme##

BROKEN AND IS BEING WORKED ON AS OF 09-2020

SKIP - Simply run the **preview.sh** file. It will install **plymouth-x11** if required. Then follow the instructions.

####Current Preview####
![]TO BE ADDED SOON

##LICENSE##
Copyright (c) 2020
MIT License

Permission is hereby granted, free of charge, to any person obtaining copy of this software and associated documentation 
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the 
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
